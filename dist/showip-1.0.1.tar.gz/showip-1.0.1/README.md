# showip
Get information about your IP or any other IP
